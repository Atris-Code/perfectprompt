# Phoenix Dashboard — Frontend Integrado (Postgres + WS)

Este zip es el dashboard React con:
- Auth real (JWT) contra backend Fastify
- Persistencia real (Postgres/Prisma) para Checklist, QC, Mass, Mirror, Batch, Oracle, Timeline
- WebSocket real para telemetría y alarmas (stream)

## Requisitos
- Backend corriendo (ver paquete `phoenix-postgres-ws`)
- Frontend: Node 18+

## Variables de entorno (Vite)
Crea `.env` en la raíz del frontend:
```env
VITE_API_BASE_URL=http://localhost:8080
VITE_WS_URL=ws://localhost:8080/ws
```

## Correr
```bash
npm install
npm run dev
```

## Login (seed)
Selecciona un usuario seed (operator@phoenix.local, etc.) y password `phoenix`.

## Notas
- Los bloqueos SOP vienen desde el backend como errores (409) con códigos tipo `GATE_*`.
- La UI los mapea a mensajes “Bloqueo SOP”.
