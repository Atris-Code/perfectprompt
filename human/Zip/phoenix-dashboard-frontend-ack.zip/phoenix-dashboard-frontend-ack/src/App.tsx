import { Navigate, Route, Routes } from "react-router-dom";
import LoginPage from "@/pages/LoginPage";
import HomeOTPage from "@/pages/ot/HomeOTPage";
import LiveRunPage from "@/pages/ot/LiveRunPage";
import HseChecklistPage from "@/pages/ot/HseChecklistPage";
import MassBalancePage from "@/pages/ot/MassBalancePage";
import AnalyticsPage from "@/pages/ot/AnalyticsPage";
import MirrorCheckPage from "@/pages/ot/MirrorCheckPage";
import BatchPage from "@/pages/ot/BatchPage";
import HomeITPage from "@/pages/it/HomeITPage";
import AssetLedgerPage from "@/pages/it/AssetLedgerPage";
import AdminPage from "@/pages/AdminPage";
import { RequireRole } from "@/lib/auth/auth";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/login" element={<LoginPage />} />

      <Route path="/ot/home" element={<RequireRole roles={["Operator","HSE","QA","Engineer","Admin"]}><HomeOTPage /></RequireRole>} />
      <Route path="/ot/runs/:id/live" element={<RequireRole roles={["Operator","HSE","QA","Engineer","Admin"]}><LiveRunPage /></RequireRole>} />
      <Route path="/ot/runs/:id/hse" element={<RequireRole roles={["Operator","HSE","Admin"]}><HseChecklistPage /></RequireRole>} />
      <Route path="/ot/runs/:id/mass-balance" element={<RequireRole roles={["Operator","Engineer","Admin"]}><MassBalancePage /></RequireRole>} />
      <Route path="/ot/runs/:id/analytics" element={<RequireRole roles={["QA","Engineer","Admin"]}><AnalyticsPage /></RequireRole>} />
      <Route path="/ot/runs/:id/mirror-check" element={<RequireRole roles={["QA","Engineer","Admin"]}><MirrorCheckPage /></RequireRole>} />
      <Route path="/ot/batches/:id" element={<RequireRole roles={["QA","Engineer","Admin"]}><BatchPage /></RequireRole>} />

      <Route path="/it/home" element={<RequireRole roles={["Viewer","Admin","Engineer","QA"]}><HomeITPage /></RequireRole>} />
      <Route path="/it/asset-ledger" element={<RequireRole roles={["Viewer","Admin","Engineer","QA"]}><AssetLedgerPage /></RequireRole>} />

      <Route path="/admin" element={<RequireRole roles={["Admin"]}><AdminPage /></RequireRole>} />

      <Route path="*" element={<div className="p-6">404</div>} />
    </Routes>
  );
}
