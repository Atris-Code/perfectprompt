import { cn } from "@/lib/utils/cn";

export function Badge(props: { variant: "ok"|"warn"|"crit"|"info"|"muted"; children: React.ReactNode }) {
  const map = {
    ok: "bg-ok/20 text-ok border-ok/30",
    warn: "bg-warn/20 text-warn border-warn/30",
    crit: "bg-crit/20 text-crit border-crit/30",
    info: "bg-info/20 text-info border-info/30",
    muted: "bg-surface2 text-muted border-borderc",
  } as const;

  return (
    <span className={cn("inline-flex items-center px-2.5 py-1 rounded-full border text-xs", map[props.variant])}>
      {props.children}
    </span>
  );
}
