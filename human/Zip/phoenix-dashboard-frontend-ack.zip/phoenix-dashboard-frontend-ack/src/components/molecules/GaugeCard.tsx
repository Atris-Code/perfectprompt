export function GaugeCard(props: {
  title: string;
  value: number;
  unit: string;
  min: number;
  max: number;
  greenRange?: [number, number];
}) {
  const pct = Math.max(0, Math.min(100, ((props.value - props.min) / (props.max - props.min)) * 100));
  const inGreen =
    props.greenRange ? props.value >= props.greenRange[0] && props.value <= props.greenRange[1] : false;

  return (
    <div className="rounded-[12px] bg-surface p-4 border border-borderc shadow-soft">
      <div className="text-sm text-muted">{props.title}</div>
      <div className="mt-2 text-3xl font-semibold">
        {props.value.toFixed(1)} <span className="text-base text-muted">{props.unit}</span>
      </div>

      <div className="mt-3 h-2 rounded-full bg-surface2 overflow-hidden">
        <div
          className="h-2 rounded-full"
          style={{ width: `${pct}%`, background: inGreen ? "hsl(var(--ok))" : "hsl(var(--warn))" }}
        />
      </div>

      {props.greenRange && (
        <div className="mt-2 text-xs text-muted">
          Zona verde: {props.greenRange[0]}–{props.greenRange[1]} {props.unit}
        </div>
      )}
    </div>
  );
}
