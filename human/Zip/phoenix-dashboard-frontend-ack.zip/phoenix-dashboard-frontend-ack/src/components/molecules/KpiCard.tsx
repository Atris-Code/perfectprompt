import { cn } from "@/lib/utils/cn";

export function KpiCard(props: {
  title: string;
  value: string;
  unit?: string;
  status?: "ok" | "warn" | "crit" | "info";
  subtitle?: string;
  onClick?: () => void;
}) {
  const s = props.status ?? "info";
  const ring =
    s === "ok" ? "ring-ok/40" : s === "warn" ? "ring-warn/40" : s === "crit" ? "ring-crit/40" : "ring-info/40";

  return (
    <button
      onClick={props.onClick}
      className={cn(
        "w-full text-left rounded-[12px] bg-surface p-4 border border-borderc shadow-soft",
        "hover:bg-surface2 transition",
        "ring-1",
        ring
      )}
    >
      <div className="text-sm text-muted">{props.title}</div>
      <div className="mt-1 flex items-baseline gap-2">
        <div className="text-2xl font-semibold">{props.value}</div>
        {props.unit && <div className="text-sm text-muted">{props.unit}</div>}
      </div>
      {props.subtitle && <div className="mt-2 text-xs text-muted">{props.subtitle}</div>}
    </button>
  );
}
