import type { Alarm } from "@/lib/api/types";
import { Badge } from "@/components/atoms/Badge";

export function AlarmPanel(props: {
  alarms: Alarm[];
  onAcknowledge: (id: string) => void;
}) {
  return (
    <div className="rounded-[12px] bg-surface border border-borderc shadow-soft">
      <div className="p-4 border-b border-borderc flex items-center justify-between">
        <div className="font-semibold">Alarmas</div>
        <Badge variant={props.alarms.length ? "warn" : "ok"}>{props.alarms.length} activas</Badge>
      </div>

      <div className="divide-y divide-[hsl(var(--border))]">
        {props.alarms.length === 0 ? (
          <div className="p-4 text-sm text-muted">Sin alarmas activas.</div>
        ) : (
          props.alarms.map((a) => (
            <div key={a.id} className="p-4 flex gap-3">
              <div
                className="mt-1 h-2 w-2 rounded-full"
                style={{ background: a.severity === "crit" ? "hsl(var(--crit))" : "hsl(var(--warn))" }}
              />
              <div className="flex-1">
                <div className="text-sm">{a.message}</div>
                {a.recommendedAction && <div className="text-xs text-muted mt-1">{a.recommendedAction}</div>}
                <div className="text-xs text-muted mt-1">{new Date(a.ts).toLocaleString()}</div>
              </div>
              {!a.acknowledged && (
                <button
                  className="text-xs px-3 py-1 rounded-full border border-borderc hover:bg-surface2"
                  onClick={() => props.onAcknowledge(a.id)}
                >
                  Reconocer
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
