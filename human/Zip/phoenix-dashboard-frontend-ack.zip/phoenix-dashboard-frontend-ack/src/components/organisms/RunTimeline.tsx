import type { ManualEvent } from "@/lib/api/mockClient";

export function RunTimeline(props: { events: ManualEvent[] }) {
  return (
    <div className="rounded-[12px] bg-surface border border-borderc shadow-soft">
      <div className="p-4 border-b border-borderc flex items-center justify-between">
        <div className="font-semibold">Timeline</div>
        <div className="text-xs text-muted">{props.events.length} eventos</div>
      </div>
      <div className="p-4 space-y-3">
        {props.events.length === 0 ? (
          <div className="text-sm text-muted">Sin eventos.</div>
        ) : (
          props.events.map((e) => (
            <div key={e.id} className="flex gap-3">
              <div className="mt-1 h-2 w-2 rounded-full bg-info" />
              <div className="flex-1">
                <div className="text-sm">{e.description}</div>
                <div className="text-xs text-muted">{new Date(e.ts).toLocaleString()} · {e.by}</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
