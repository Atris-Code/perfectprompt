import { NavLink } from "react-router-dom";
import { Home, Activity, ShieldCheck, Scale, FlaskConical, CheckCircle2, Layers, Coins, Settings } from "lucide-react";
import { cn } from "@/lib/utils/cn";

const item = (to: string, label: string, Icon: any) => ({ to, label, Icon });

export function Sidebar(props: { runId?: string }) {
  const runId = props.runId ?? "024";
  const items = [
    item("/ot/home", "Home", Home),
    item(`/ot/runs/${runId}/live`, "Live Run", Activity),
    item(`/ot/runs/${runId}/hse`, "Checklist HSE", ShieldCheck),
    item(`/ot/runs/${runId}/mass-balance`, "Balance de Masa", Scale),
    item(`/ot/runs/${runId}/analytics`, "Analítica", FlaskConical),
    item(`/ot/runs/${runId}/mirror-check`, "Mirror-Check", CheckCircle2),
    item(`/ot/batches/B-011`, "Batch", Layers),
    item("/it/asset-ledger", "Asset Ledger", Coins),
    item("/admin", "Admin", Settings),
  ];

  return (
    <div className="w-64 border-r border-borderc bg-surface p-3">
      <div className="text-xs text-muted px-3 py-2">Navegación</div>
      <div className="space-y-1">
        {items.map((it) => (
          <NavLink
            key={it.to}
            to={it.to}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 px-3 py-2 rounded-xl text-sm hover:bg-surface2",
                isActive ? "bg-surface2" : ""
              )
            }
          >
            <it.Icon className="h-4 w-4 text-muted" />
            <span>{it.label}</span>
          </NavLink>
        ))}
      </div>
    </div>
  );
}
