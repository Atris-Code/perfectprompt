import { Flame } from "lucide-react";

export function Topbar(props: { title: string; right?: React.ReactNode }) {
  return (
    <div className="h-16 px-6 border-b border-borderc flex items-center justify-between bg-surface">
      <div className="flex items-center gap-3">
        <div className="h-9 w-9 rounded-xl bg-primary/20 flex items-center justify-center">
          <Flame className="h-5 w-5" />
        </div>
        <div className="font-semibold">{props.title}</div>
      </div>
      <div>{props.right}</div>
    </div>
  );
}
