import { http } from "./httpClient";

export type Role = "Operator"|"HSE"|"QA"|"Engineer"|"Viewer"|"Admin";

export const api = {
  login(email: string, password: string) {
    return http<{token: string; user: {id: string; name: string; role: Role}}>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
  },

  // Runs
  runs(token: string) { return http<any[]>("/runs", { token }); },
  runSummary(token: string, runId: string) { return http<any>(`/runs/${runId}/summary`, { token }); },

  // Timeline
  listEvents(token: string, runId: string) { return http<any[]>(`/runs/${runId}/events`, { token }); },
  addEvent(token: string, runId: string, message: string) { return http<any>(`/runs/${runId}/events`, { token, method:"POST", body: JSON.stringify({ message }) }); },

  // Alarms
  alarms(token: string, runId: string) { return http<any[]>(`/runs/${runId}/alarms`, { token }); },
  ackAlarm(token: string, alarmId: string) { return http<any>(`/alarms/${alarmId}/ack`, { token, method:"POST" }); },

  // HSE
  getHse(token: string, runId: string) { return http<any>(`/runs/${runId}/hse`, { token }); },
  setHseItem(token: string, runId: string, key: string, checked: boolean) { return http<any>(`/runs/${runId}/hse/items/${key}`, { token, method:"PATCH", body: JSON.stringify({ checked }) }); },
  addHseEvidence(token: string, runId: string, key: string, ev: {name:string;url:string;sha256?:string}) { 
    return http<any>(`/runs/${runId}/hse/items/${key}/evidence`, { token, method:"POST", body: JSON.stringify(ev) });
  },
  signHse(token: string, runId: string, role: "Operator"|"HSE") { return http<any>(`/runs/${runId}/hse/sign`, { token, method:"POST", body: JSON.stringify({ role }) }); },
  completeHse(token: string, runId: string) { return http<any>(`/runs/${runId}/hse/complete`, { token, method:"POST" }); },

  // Mass
  massRecords(token: string, runId: string) { return http<any[]>(`/runs/${runId}/mass-records`, { token }); },
  addMassRecord(token: string, runId: string, rec: any) { return http<any>(`/runs/${runId}/mass-records`, { token, method:"POST", body: JSON.stringify(rec) }); },
  massBalance(token: string, runId: string) { return http<any>(`/runs/${runId}/mass-balance`, { token }); },

  // Lab / QC
  labResults(token: string, runId: string) { return http<any[]>(`/runs/${runId}/lab-results`, { token }); },
  uploadLab(token: string, runId: string, payload: {type:string;fileUrl:string;meta?:any}) { return http<any>(`/runs/${runId}/lab-results`, { token, method:"POST", body: JSON.stringify(payload) }); },
  setQc(token: string, labResultId: string, qcStatus: "Pending"|"Approved"|"Rejected") { return http<any>(`/lab-results/${labResultId}/qc`, { token, method:"PATCH", body: JSON.stringify({ qcStatus }) }); },

  // Mirror
  runMirror(token: string, runId: string) { return http<any>(`/runs/${runId}/mirror-check/run`, { token, method:"POST" }); },
  getMirror(token: string, runId: string) { return http<any>(`/runs/${runId}/mirror-check`, { token }); },
  signMirror(token: string, runId: string, role: "QA"|"Engineer") { return http<any>(`/runs/${runId}/mirror-check/sign`, { token, method:"POST", body: JSON.stringify({ role }) }); },

  // Batch + Oracle
  createBatch(token: string, runId: string) { return http<any>(`/runs/${runId}/batch/create`, { token, method:"POST" }); },
  getBatch(token: string, batchId: string) { return http<any>(`/batches/${batchId}`, { token }); },
  approveBatch(token: string, batchId: string, role: "QA"|"Engineer") { return http<any>(`/batches/${batchId}/approve`, { token, method:"POST", body: JSON.stringify({ role }) }); },
  emitOracle(token: string, batchId: string) { return http<any>(`/batches/${batchId}/oracle/emit`, { token, method:"POST" }); },
  assetLedger(token: string) { return http<any[]>(`/asset-ledger`, { token }); },
};
