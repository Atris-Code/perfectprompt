export function mapGateError(err: unknown): { title: string; detail: string; links?: { label: string; to: string }[] } | null {
  const msg = (err as any)?.message as string | undefined;
  if (!msg) return null;

  if (msg === "GATE_HSE_CHECKLIST_INCOMPLETE" || msg === "CHECKLIST_INCOMPLETE") {
    return {
      title: "Bloqueo SOP: Checklist HSE",
      detail: "La operación requiere checklist completado (ítems + firmas Operator/HSE).",
      links: [{ label: "Ir a Checklist HSE", to: "/ot/runs/024/hse" }],
    };
  }
  if (msg === "GATE_QC_NOT_APPROVED") {
    return {
      title: "Bloqueo SOP: QC no aprobado",
      detail: "La analítica (GCMS/MICRO_GC/TGA) debe estar en estado Approved.",
      links: [{ label: "Ir a Analítica & QC", to: "/ot/runs/024/analytics" }],
    };
  }
  if (msg === "GATE_MASS_CLOSURE_LT_95") {
    return {
      title: "Bloqueo SOP: Cierre de masa",
      detail: "El cierre de masa debe ser ≥ 95% para validar y crear Batch.",
      links: [{ label: "Ir a Balance de Masa", to: "/ot/runs/024/mass-balance" }],
    };
  }
  if (msg === "GATE_MIRROR_NOT_RUN") {
    return {
      title: "Bloqueo SOP: Mirror-Check",
      detail: "Debe ejecutarse Mirror-Check antes de firmar o crear Batch.",
      links: [{ label: "Ir a Mirror-Check", to: "/ot/runs/024/mirror-check" }],
    };
  }
  if (msg === "GATE_MIRROR_NOT_PASS") {
    return { title: "Bloqueo SOP: Mirror-Check FAIL", detail: "El Mirror-Check debe ser PASS para crear Batch." };
  }
  if (msg === "GATE_MIRROR_NOT_SIGNED") {
    return { title: "Bloqueo SOP: Firmas Mirror-Check", detail: "Se requieren firmas QA y Engineer para crear Batch." };
  }
  if (msg === "GATE_BATCH_NOT_SIGNED") {
    return { title: "Bloqueo SOP: Firmas Batch", detail: "El Batch debe estar firmado por QA y Engineer para emitir oráculo." };
  }
  return null;
}
