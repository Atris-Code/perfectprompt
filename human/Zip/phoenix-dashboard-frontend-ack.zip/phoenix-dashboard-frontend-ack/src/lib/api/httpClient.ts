export const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8080";

export type HttpError = { error: string };

export async function http<T>(path: string, opts: RequestInit & { token?: string } = {}): Promise<T> {
  const headers = new Headers(opts.headers ?? {});
  headers.set("Content-Type", "application/json");
  if (opts.token) headers.set("Authorization", `Bearer ${opts.token}`);

  const res = await fetch(`${API_BASE}${path}`, { ...opts, headers });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;

  if (!res.ok) {
    const msg = (data && data.error) ? data.error : `HTTP_${res.status}`;
    throw new Error(msg);
  }
  return data as T;
}
