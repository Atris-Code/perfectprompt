import type {
  Alarm, Batch, LabResult, MassRecord, MirrorCheck, OracleEvent, Role, RunStatus
} from "./types";

type User = { id: string; name: string; role: Role; mfa: boolean };

type Run = {
  id: string;
  status: RunStatus;
  recipe: { tempC: number; n2Flow: number };
  operatorId: string;
  startedAt?: string;
  completedAt?: string;
};

export type ChecklistItemKey = "LEAK_CHECK" | "INERTIZATION" | "LINES_HEATED" | "PPE";
export type ChecklistState = {
  runId: string;
  items: Record<ChecklistItemKey, { checked: boolean; evidence?: { name: string; url: string }[] }>;
  signatures: { operator?: { name: string; at: string }; hse?: { name: string; at: string } };
  completed: boolean;
};

export type ManualEvent = { id: string; runId: string; description: string; ts: string; by: string };

export type MirrorSignatures = {
  runId: string;
  qa?: { name: string; at: string };
  engineer?: { name: string; at: string };
};

const nowIso = () => new Date().toISOString();

const users: User[] = [
  { id: "u-1", name: "Operador", role: "Operator", mfa: false },
  { id: "u-2", name: "QA", role: "QA", mfa: true },
  { id: "u-3", name: "Ingeniero", role: "Engineer", mfa: true },
  { id: "u-4", name: "HSE", role: "HSE", mfa: false },
  { id: "u-5", name: "Inversor", role: "Viewer", mfa: false },
  { id: "u-6", name: "Admin", role: "Admin", mfa: true },
];

const runs: Record<string, Run> = {
  "024": { id: "024", status: "Running", recipe: { tempC: 600, n2Flow: 80 }, operatorId: "u-1", startedAt: nowIso() },
};

const alarms: Alarm[] = [];

const manualEvents: ManualEvent[] = [
  { id: "e-1", runId: "024", description: "Inicio corrida", ts: nowIso(), by: "Operador" },
];

const checklist: ChecklistState = {
  runId: "024",
  items: {
    LEAK_CHECK: { checked: false, evidence: [] },
    INERTIZATION: { checked: false, evidence: [] },
    LINES_HEATED: { checked: false, evidence: [] },
    PPE: { checked: false, evidence: [] },
  },
  signatures: {},
  completed: false,
};

const massRecords: MassRecord[] = [
  { id: "m-1", runId: "024", type: "FEED", mass_g: 100.00, ts: nowIso(), scaleId: "scale-1", uncertainty_g: 0.01 },
  { id: "m-2", runId: "024", type: "LIQUID", mass_g: 80.10, ts: nowIso(), scaleId: "scale-1", uncertainty_g: 0.01 },
  { id: "m-3", runId: "024", type: "GAS", mass_g: 19.60, ts: nowIso(), method: "wet-gas-meter", uncertainty_g: 0.10 },
  { id: "m-4", runId: "024", type: "SOLID", mass_g: 0.30, ts: nowIso(), method: "weighing", uncertainty_g: 0.01 },
];

const labResults: LabResult[] = [
  { id: "lr-1", runId: "024", type: "GCMS", fileUrl: "/evidence/gcms_run024.pdf", qcStatus: "Pending" },
  { id: "lr-2", runId: "024", type: "MICRO_GC", fileUrl: "/evidence/microgc_run024.csv", qcStatus: "Pending" },
  { id: "lr-3", runId: "024", type: "TGA", fileUrl: "/evidence/tga_run024.png", qcStatus: "Approved", meta: { coke_pct: 0.01 } },
];

let mirrorCheck: MirrorCheck | null = null;
let mirrorSigs: MirrorSignatures = { runId: "024" };

let batch: Batch | null = null;
let oracleEvents: OracleEvent[] = [];

function computeMassBalance(runId: string) {
  const feed = massRecords.filter(m => m.runId === runId && m.type === "FEED").reduce((s,m)=>s+m.mass_g,0);
  const liq = massRecords.filter(m => m.runId === runId && m.type === "LIQUID").reduce((s,m)=>s+m.mass_g,0);
  const gas = massRecords.filter(m => m.runId === runId && m.type === "GAS").reduce((s,m)=>s+m.mass_g,0);
  const sol = massRecords.filter(m => m.runId === runId && m.type === "SOLID").reduce((s,m)=>s+m.mass_g,0);
  const closure = feed > 0 ? ((liq+gas+sol)/feed)*100 : 0;
  return { feed, liq, gas, sol, closure };
}

function pseudoHash(input: string) {
  let h = 2166136261;
  for (let i=0;i<input.length;i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return "0x" + (h >>> 0).toString(16).padStart(8,"0");
}

function addEvent(runId: string, description: string, by: string) {
  manualEvents.unshift({ id: `e-${manualEvents.length+1}`, runId, description, ts: nowIso(), by });
}

function qcAllApproved(runId: string) {
  const needed = labResults.filter(l => l.runId === runId);
  return needed.length > 0 && needed.every(l => l.qcStatus === "Approved");
}

export const mockApi = {
  async login(role: Role): Promise<{ token: string; user: User }> {
    const user = users.find(u => u.role === role) ?? users[0];
    return { token: "mock-token", user };
  },

  async listManualEvents(runId: string): Promise<ManualEvent[]> {
    return manualEvents.filter(e => e.runId === runId);
  },

  async addManualEvent(runId: string, description: string, by: string): Promise<ManualEvent> {
    addEvent(runId, description, by);
    return manualEvents[0];
  },

  async getChecklist(runId: string): Promise<ChecklistState> {
    if (checklist.runId !== runId) throw new Error("Checklist not found");
    return checklist;
  },

  async setChecklistItem(runId: string, key: ChecklistItemKey, checked: boolean) {
    if (checklist.runId !== runId) throw new Error("Checklist not found");
    checklist.items[key].checked = checked;
    checklist.completed = false;
    return checklist;
  },

  async addChecklistEvidence(runId: string, key: ChecklistItemKey, fileName: string) {
    if (checklist.runId !== runId) throw new Error("Checklist not found");
    checklist.items[key].evidence = checklist.items[key].evidence ?? [];
    checklist.items[key].evidence!.push({ name: fileName, url: `/evidence/${fileName}` });
    checklist.completed = false;
    addEvent(runId, `Evidencia HSE: ${key} → ${fileName}`, "Operador");
    return checklist;
  },

  async signChecklist(runId: string, by: "Operator" | "HSE") {
    if (checklist.runId !== runId) throw new Error("Checklist not found");
    const stamp = { name: by === "Operator" ? "Operador" : "HSE", at: nowIso() };
    if (by === "Operator") checklist.signatures.operator = stamp;
    if (by === "HSE") checklist.signatures.hse = stamp;
    checklist.completed = false;
    addEvent(runId, `Firma checklist HSE: ${by}`, "Sistema");
    return checklist;
  },

  async completeChecklist(runId: string) {
    if (checklist.runId !== runId) throw new Error("Checklist not found");
    const allChecked = Object.values(checklist.items).every(i => i.checked);
    if (!allChecked) throw new Error("Checklist incompleta: faltan ítems");
    if (!checklist.signatures.operator || !checklist.signatures.hse) throw new Error("Checklist incompleta: faltan firmas");
    checklist.completed = true;
    addEvent(runId, "Checklist HSE completada", "Sistema");
    return checklist;
  },

  async listMassRecords(runId: string): Promise<MassRecord[]> {
    return massRecords.filter(m => m.runId === runId);
  },

  async addMassRecord(runId: string, rec: Omit<MassRecord,"id"|"ts"|"runId">): Promise<MassRecord> {
    const created: MassRecord = { ...rec, runId, id: `m-${massRecords.length+1}`, ts: nowIso() };
    massRecords.push(created);
    addEvent(runId, `Pesada: ${created.type} ${created.mass_g.toFixed(2)} g`, "Operador");
    return created;
  },

  async getMassBalance(runId: string) {
    return computeMassBalance(runId);
  },

  async listLabResults(runId: string): Promise<LabResult[]> {
    return labResults.filter(l => l.runId === runId);
  },

  async uploadLabResult(runId: string, type: LabResult["type"], fileName: string): Promise<LabResult> {
    const lr: LabResult = {
      id: `lr-${labResults.length+1}`,
      runId,
      type,
      fileUrl: `/evidence/${fileName}`,
      qcStatus: "Pending",
    };
    labResults.push(lr);
    addEvent(runId, `Upload analítica: ${type} → ${fileName}`, "Sistema");
    return lr;
  },

  async setQcStatus(labResultId: string, qcStatus: LabResult["qcStatus"]) {
    const lr = labResults.find(l => l.id === labResultId);
    if (!lr) throw new Error("LabResult not found");
    lr.qcStatus = qcStatus;
    addEvent(lr.runId, `QC ${lr.type}: ${qcStatus}`, "QA");
    return lr;
  },

  async runMirrorCheck(runId: string): Promise<MirrorCheck> {
    if (!checklist.completed) throw new Error("Bloqueo: Checklist HSE no completada.");
    if (!qcAllApproved(runId)) throw new Error("Bloqueo: Analítica sin QC aprobado.");

    const { feed, liq, gas, closure } = computeMassBalance(runId);
    const liquidsPct = feed ? (liq/feed)*100 : 0;
    const gasPct = feed ? (gas/feed)*100 : 0;
    const cokePct = (labResults.find(l=>l.runId===runId && l.type==="TGA")?.meta?.coke_pct as number) ?? 0.0;

    const targets = { liquids: 80.25, gas: 19.74, coke: 0.01 };
    const deviations = {
      liquids: liquidsPct - targets.liquids,
      gas: gasPct - targets.gas,
      coke: cokePct - targets.coke,
      massClosure: closure - 100,
    };

    const tol = 5.0;
    const pass =
      Math.abs(deviations.liquids) <= tol &&
      Math.abs(deviations.gas) <= tol &&
      cokePct < 0.1 &&
      closure >= 95;

    mirrorCheck = {
      runId,
      result: pass ? "PASS" : "FAIL",
      targets,
      actuals: { liquids: liquidsPct, gas: gasPct, coke: cokePct, massClosure: closure },
      deviations,
      ts: nowIso(),
    };

    mirrorSigs = { runId };
    addEvent(runId, `Mirror-Check ejecutado: ${mirrorCheck.result}`, "Sistema");
    return mirrorCheck;
  },

  async getMirrorSignatures(runId: string): Promise<MirrorSignatures> {
    if (mirrorSigs.runId !== runId) mirrorSigs = { runId };
    return mirrorSigs;
  },

  async signMirrorCheck(runId: string, by: "QA" | "Engineer") {
    if (!mirrorCheck || mirrorCheck.runId !== runId) throw new Error("Mirror-Check no ejecutado.");
    const stamp = { name: by === "QA" ? "QA" : "Ingeniero", at: nowIso() };
    if (by === "QA") mirrorSigs.qa = stamp;
    if (by === "Engineer") mirrorSigs.engineer = stamp;
    addEvent(runId, `Firma Mirror-Check: ${by}`, "Sistema");
    return mirrorSigs;
  },

  async createBatch(runId: string): Promise<Batch> {
    if (!mirrorCheck || mirrorCheck.runId !== runId || mirrorCheck.result !== "PASS") {
      throw new Error("Mirror-Check debe ser PASS antes de crear Batch");
    }
    if (!mirrorSigs.qa || !mirrorSigs.engineer) {
      throw new Error("Bloqueo: Mirror-Check debe estar firmado por QA y Engineer.");
    }
    if (!qcAllApproved(runId)) throw new Error("Bloqueo: Analítica sin QC aprobado.");

    const mb = computeMassBalance(runId);
    if (mb.closure < 95) throw new Error("Bloqueo: cierre de masa < 95%.");

    const evidenceHash = pseudoHash(JSON.stringify({ runId, mb, labResults: labResults.filter(l=>l.runId===runId), checklist, mirrorCheck, mirrorSigs }));

    batch = {
      id: "B-011",
      runId,
      status: "APPROVED",
      validatedOil_g: mb.liq,
      evidenceHash,
    };
    addEvent(runId, `Batch creado: ${batch.id}`, "Sistema");
    return batch;
  },

  async getBatch(batchId: string): Promise<Batch | null> {
    return batch?.id === batchId ? batch : null;
  },

  async approveBatch(batchId: string, by: "QA" | "Engineer"): Promise<Batch> {
    if (!batch || batch.id !== batchId) throw new Error("Batch not found");
    const stamp = { name: by === "QA" ? "QA" : "Ingeniero", at: nowIso() };
    if (by === "QA") batch.approvedByQA = stamp;
    if (by === "Engineer") batch.approvedByEngineer = stamp;
    addEvent(batch.runId, `Firma ${by} en Batch ${batchId}`, "Sistema");
    return batch;
  },

  async emitOracleEvent(batchId: string): Promise<OracleEvent> {
    if (!batch || batch.id !== batchId) throw new Error("Batch not found");
    if (!batch.approvedByQA || !batch.approvedByEngineer) throw new Error("Batch debe estar firmado por QA y Engineer");

    const quantityKg = batch.validatedOil_g / 1000;
    const ev: OracleEvent = {
      id: `ev-${oracleEvents.length+1}`,
      batchId,
      type: "ValidatedOilKg",
      quantityKg,
      evidenceHash: batch.evidenceHash,
      oracleSignature: pseudoHash("oracle:"+batch.evidenceHash+":"+quantityKg),
      ts: nowIso(),
    };
    oracleEvents = [ev, ...oracleEvents];
    addEvent(batch.runId, `Oráculo emitido: ValidatedOilKg ${quantityKg.toFixed(4)} kg`, "Oráculo");
    return ev;
  },

  async listOracleEvents(batchId: string): Promise<OracleEvent[]> {
    return oracleEvents.filter(e => e.batchId === batchId);
  },

  async listAssetLedger(): Promise<{ batchId: string; oilKg: number; date: string; status: string }[]> {
    return oracleEvents
      .filter(e => e.type === "ValidatedOilKg")
      .map(e => ({ batchId: e.batchId, oilKg: e.quantityKg ?? 0, date: e.ts.slice(0,10), status: "Validated" }));
  },

  // Existing alarms API used elsewhere
  async listAlarms(runId: string): Promise<Alarm[]> {
    return alarms.filter(a => a.runId === runId);
  },
  async acknowledgeAlarm(id: string): Promise<void> {
    const a = alarms.find(x => x.id === id);
    if (a) a.acknowledged = true;
  },
};
