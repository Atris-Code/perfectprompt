export type Role = "Operator" | "QA" | "Engineer" | "HSE" | "Viewer" | "Admin";

export type RunStatus = "Planned" | "Running" | "Completed" | "Locked";

export type Severity = "warn" | "crit";

export type SensorTag = "T_REACTOR" | "P_REACTOR" | "N2_FLOW";

export type SensorSample = {
  runId: string;
  tag: SensorTag;
  value: number;
  unit: string;
  ts: string; // ISO
  quality?: "good" | "suspect" | "bad";
};

export type Alarm = {
  id: string;
  runId: string;
  severity: Severity;
  message: string;
  tag?: SensorTag;
  recommendedAction?: string;
  ts: string;
  acknowledged?: boolean;
};

export type MassRecordType = "FEED" | "LIQUID" | "GAS" | "SOLID";
export type MassRecord = {
  id: string;
  runId: string;
  type: MassRecordType;
  mass_g: number;
  method?: string;
  scaleId?: string;
  uncertainty_g?: number;
  ts: string;
};

export type QcStatus = "Pending" | "Approved" | "Rejected";
export type LabResultType = "GCMS" | "MICRO_GC" | "TGA";
export type LabResult = {
  id: string;
  runId: string;
  type: LabResultType;
  fileUrl: string;
  qcStatus: QcStatus;
  meta?: Record<string, string | number>;
};

export type MirrorCheckResult = "PASS" | "WARN" | "FAIL";
export type MirrorCheck = {
  runId: string;
  result: MirrorCheckResult;
  targets: { liquids: number; gas: number; coke: number };
  actuals: { liquids: number; gas: number; coke: number; massClosure: number };
  deviations: Record<string, number>;
  ts: string;
};

export type Batch = {
  id: string;
  runId: string;
  status: "APPROVED" | "REJECTED";
  validatedOil_g: number;
  evidenceHash: string;
  approvedByQA?: { name: string; at: string };
  approvedByEngineer?: { name: string; at: string };
};

export type OracleEventType = "ValidatedOilKg" | "BatchRevoked";
export type OracleEvent = {
  id: string;
  batchId: string;
  type: OracleEventType;
  quantityKg?: number;
  evidenceHash: string;
  oracleSignature: string;
  ts: string;
};
