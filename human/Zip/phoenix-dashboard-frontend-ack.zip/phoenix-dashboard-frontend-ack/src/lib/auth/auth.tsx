import React, { createContext, useContext, useMemo, useState } from "react";
import type { Role } from "@/lib/api/types";
import { api } from "@/lib/api/apiClient";

type User = { id: string; name: string; role: Role };
type AuthState = { token: string; user: User } | null;

type AuthCtx = {
  auth: AuthState;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
};

const Ctx = createContext<AuthCtx | null>(null);

const STORAGE_KEY = "phoenix_auth_v1";

function loadAuth(): AuthState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as AuthState;
  } catch {
    return null;
  }
}

function saveAuth(auth: AuthState) {
  try {
    if (!auth) localStorage.removeItem(STORAGE_KEY);
    else localStorage.setItem(STORAGE_KEY, JSON.stringify(auth));
  } catch {
    // ignore
  }
}

export function AuthProvider(props: { children: React.ReactNode }) {
  const [auth, setAuth] = useState<AuthState>(() => loadAuth());

  const value = useMemo<AuthCtx>(() => ({
    auth,
    async login(email, password) {
      const res = await api.login(email, password);
      const next = { token: res.token, user: res.user };
      setAuth(next);
      saveAuth(next);
    },
    logout() {
      setAuth(null);
      saveAuth(null);
    },
  }), [auth]);

  return <Ctx.Provider value={value}>{props.children}</Ctx.Provider>;
}

export function useAuth() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

export function RequireRole(props: { roles: Role[]; children: React.ReactNode }) {
  const { auth } = useAuth();
  if (!auth) return <div className="p-6">No autenticado. Ve a /login</div>;
  if (!props.roles.includes(auth.user.role)) return <div className="p-6">Acceso denegado para rol: {auth.user.role}</div>;
  return <>{props.children}</>;
}
