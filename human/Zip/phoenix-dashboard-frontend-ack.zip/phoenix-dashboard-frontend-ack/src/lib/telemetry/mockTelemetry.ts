import type { Alarm, SensorSample, SensorTag } from "@/lib/api/types";

type Listener<T> = (data: T) => void;

export class MockTelemetry {
  private intervalId: number | null = null;
  private sampleListeners: Listener<SensorSample>[] = [];
  private alarmListeners: Listener<Alarm[]>[] = [];
  private alarms: Alarm[] = [];
  private t = 600.1;
  private p = 1.02;
  private n2 = 80.0;

  constructor(private runId: string) {}

  onSample(fn: Listener<SensorSample>) {
    this.sampleListeners.push(fn);
  }

  onAlarms(fn: Listener<Alarm[]>) {
    this.alarmListeners.push(fn);
  }

  start() {
    if (this.intervalId) return;

    this.intervalId = window.setInterval(() => {
      // small drift
      this.t += (Math.random() - 0.5) * 0.25;
      this.p += (Math.random() - 0.5) * 0.02;
      this.n2 += (Math.random() - 0.5) * 0.8;

      const ts = new Date().toISOString();
      this.emitSample({ runId: this.runId, tag: "T_REACTOR", value: this.t, unit: "°C", ts });
      this.emitSample({ runId: this.runId, tag: "P_REACTOR", value: this.p, unit: "bar", ts });
      this.emitSample({ runId: this.runId, tag: "N2_FLOW", value: this.n2, unit: "mL/min", ts });

      // alarms: if temp out of 598-602 => warn/crit
      const out = this.t < 598 || this.t > 602;
      this.alarms = out
        ? [{
            id: "a-1",
            runId: this.runId,
            severity: Math.abs(this.t - 600) > 5 ? "crit" : "warn",
            message: "Temperatura fuera de zona verde (598–602°C)",
            tag: "T_REACTOR",
            recommendedAction: "Verificar horno y control; si persiste, detener calentamiento.",
            ts,
            acknowledged: false,
          }]
        : [];
      this.emitAlarms(this.alarms);
    }, 800);
  }

  stop() {
    if (this.intervalId) window.clearInterval(this.intervalId);
    this.intervalId = null;
  }

  private emitSample(s: SensorSample) {
    for (const fn of this.sampleListeners) fn(s);
  }
  private emitAlarms(a: Alarm[]) {
    for (const fn of this.alarmListeners) fn(a);
  }
}
