import { useEffect, useRef, useState } from "react";
import type { Alarm, SensorSample, SensorTag } from "@/lib/api/types";
import { MockTelemetry } from "./mockTelemetry";

type TelemetryState = {
  samples: Partial<Record<SensorTag, SensorSample>>;
  alarms: Alarm[];
};

export function useTelemetry(runId: string) {
  const [state, setState] = useState<TelemetryState>({ samples: {}, alarms: [] });
  const telRef = useRef<MockTelemetry | null>(null);

  useEffect(() => {
    const tel = new MockTelemetry(runId);
    telRef.current = tel;

    tel.onSample((s) => {
      setState((prev) => ({ ...prev, samples: { ...prev.samples, [s.tag]: s } }));
    });
    tel.onAlarms((alarms) => {
      setState((prev) => ({ ...prev, alarms }));
    });

    tel.start();
    return () => tel.stop();
  }, [runId]);

  return state;
}
