import { useEffect, useMemo, useState } from "react";

export type TelemetryTag = { value: number; unit: string };
export type AlarmMsg = {
  type: "alarm";
  id: string;
  ts: string;
  runId: string;
  severity: "WARN" | "CRIT";
  message: string;
  acknowledged?: boolean;
  ackBy?: string | null;
  ackAt?: string | null;
};

export type AlarmAckMsg = {
  type: "alarm_ack";
  id: string;
  acknowledged: boolean;
  ackBy?: string | null;
  ackAt?: string | null;
};

export type TelemetryMsg =
  | { type: "hello"; runId: string }
  | { type: "telemetry"; ts: string; tags: Record<string, TelemetryTag> }
  | AlarmMsg
  | AlarmAckMsg;

export function useWsTelemetry(runId: string) {
  const WS_URL = (import.meta.env.VITE_WS_URL ?? "ws://localhost:8080/ws") as string;
  const [samples, setSamples] = useState<Record<string, TelemetryTag>>({});
  const [alarms, setAlarms] = useState<any[]>([]);

  useEffect(() => {
    const ws = new WebSocket(`${WS_URL}?runId=${encodeURIComponent(runId)}`);
    ws.onmessage = (ev) => {
      const msg = JSON.parse(ev.data) as TelemetryMsg;
      if (msg.type === "telemetry") setSamples(msg.tags);

      if (msg.type === "alarm") {
        setAlarms((prev) => {
          const next = [
            {
              id: msg.id,
              ts: msg.ts,
              severity: msg.severity,
              message: msg.message,
              runId: msg.runId,
              acknowledged: !!msg.acknowledged,
              ackBy: msg.ackBy ?? null,
              ackAt: msg.ackAt ?? null,
            },
            ...prev.filter((a) => a.id !== msg.id),
          ];
          return next.slice(0, 100);
        });
      }

      if (msg.type === "alarm_ack") {
        setAlarms((prev) =>
          prev.map((a) =>
            a.id === msg.id ? { ...a, acknowledged: msg.acknowledged, ackBy: msg.ackBy ?? a.ackBy, ackAt: msg.ackAt ?? a.ackAt } : a
          )
        );
      }
    };
    return () => ws.close();
  }, [runId, WS_URL]);

  return useMemo(() => ({ samples, alarms, setAlarms }), [samples, alarms]);
}
