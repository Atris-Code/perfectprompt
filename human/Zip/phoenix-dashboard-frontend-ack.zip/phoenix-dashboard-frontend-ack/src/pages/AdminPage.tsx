import { Topbar } from "@/components/organisms/Topbar";
import { Sidebar } from "@/components/organisms/Sidebar";

export default function AdminPage() {
  return (
    <div className="min-h-screen flex">
      <Sidebar runId="024" />
      <div className="flex-1">
        <Topbar title="Admin" />
        <div className="p-6">
          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
            <div className="font-semibold">Administración (stub)</div>
            <div className="text-sm text-muted mt-2">
              Aquí irán: usuarios/roles, calibraciones, parámetros Mirror-Check, auditoría.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
