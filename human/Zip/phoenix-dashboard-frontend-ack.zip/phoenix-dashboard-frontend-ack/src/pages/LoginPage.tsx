import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth/auth";

type UserPreset = { label: string; email: string };

const PRESETS: UserPreset[] = [
  { label: "Operator", email: "operator@phoenix.local" },
  { label: "HSE", email: "hse@phoenix.local" },
  { label: "QA", email: "qa@phoenix.local" },
  { label: "Engineer", email: "engineer@phoenix.local" },
  { label: "Viewer", email: "viewer@phoenix.local" },
  { label: "Admin", email: "admin@phoenix.local" },
];

export default function LoginPage() {
  const [preset, setPreset] = useState<string>(PRESETS[0].email);
  const [password, setPassword] = useState<string>("phoenix");
  const [err, setErr] = useState<string | null>(null);
  const nav = useNavigate();
  const { login } = useAuth();

  const label = useMemo(() => PRESETS.find(p => p.email === preset)?.label ?? "User", [preset]);

  async function onLogin() {
    setErr(null);
    try {
      await login(preset, password);
      if (label === "Viewer") nav("/it/home");
      else if (label === "Admin") nav("/admin");
      else nav("/ot/home");
    } catch (e: any) {
      setErr(e.message ?? "Error");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md rounded-[12px] bg-surface border border-borderc p-6 shadow-soft">
        <div className="text-xl font-semibold">Proyecto Phoenix</div>
        <div className="text-sm text-muted mt-1">Login (Backend real + JWT)</div>

        {err && <div className="mt-4 rounded-xl bg-crit/10 border border-crit/30 p-3 text-sm">{err}</div>}

        <div className="mt-6 space-y-3">
          <label className="text-sm text-muted">Usuario (seed)</label>
          <select
            value={preset}
            onChange={(e) => setPreset(e.target.value)}
            className="w-full bg-surface2 border border-borderc rounded-xl px-3 py-2"
          >
            {PRESETS.map(p => <option key={p.email} value={p.email}>{p.label} — {p.email}</option>)}
          </select>

          <label className="text-sm text-muted">Password</label>
          <input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            className="w-full bg-surface2 border border-borderc rounded-xl px-3 py-2"
          />

          <button onClick={onLogin} className="w-full mt-2 bg-primary/90 hover:bg-primary rounded-xl py-2 font-semibold">
            Iniciar sesión
          </button>

          <div className="text-xs text-muted mt-2">
            Backend esperado: <span className="font-mono">http://localhost:8080</span> · DB: Postgres (docker)
          </div>
        </div>
      </div>
    </div>
  );
}
