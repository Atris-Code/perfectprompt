import { useEffect, useState } from "react";
import { Topbar } from "@/components/organisms/Topbar";
import { Sidebar } from "@/components/organisms/Sidebar";
import { api } from "@/lib/api/apiClient";
import { useAuth } from "@/lib/auth/auth";

export default function AssetLedgerPage() {
  const { auth } = useAuth();
  const token = auth?.token ?? "";
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (!token) return;
    api.assetLedger(token).then(setRows).catch((e:any)=>setErr(e.message ?? "Error"));
  }, [token]);

  return (
    <div className="min-h-screen flex">
      <Sidebar runId="024" />
      <div className="flex-1">
        <Topbar title="IT — Asset Ledger" />
        <div className="p-6 space-y-4">
          {err && <div className="rounded-[12px] bg-crit/10 border border-crit/30 p-4">{err}</div>}
          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
            <table className="w-full text-sm">
              <thead className="text-muted">
                <tr className="text-left">
                  <th className="py-2">Date</th>
                  <th>Batch</th>
                  <th>Oil (kg)</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 ? (
                  <tr><td className="py-3 text-muted" colSpan={4}>Sin eventos aún.</td></tr>
                ) : rows.map((r:any, i:number) => (
                  <tr key={i} className="border-t border-borderc">
                    <td className="py-2">{r.date}</td>
                    <td className="font-mono">{r.batchId}</td>
                    <td>{Number(r.oilKg).toFixed(4)}</td>
                    <td>{r.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
