import { Link } from "react-router-dom";
import { Topbar } from "@/components/organisms/Topbar";
import { Sidebar } from "@/components/organisms/Sidebar";
import { KpiCard } from "@/components/molecules/KpiCard";

export default function HomeITPage() {
  return (
    <div className="min-h-screen flex">
      <Sidebar runId="024" />
      <div className="flex-1">
        <Topbar title="IT — Home (Viewer)" right={<Link to="/login" className="text-sm text-muted">Salir</Link>} />
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <KpiCard title="Producción validada (demo)" value="0.080" unit="kg" status="info" subtitle="Basado en Batch B-011 (cuando se emite oráculo)" />
            <KpiCard title="Valor estimado (demo)" value="$—" status="muted" subtitle="Conectar a TEA/mercado en backend real" />
            <KpiCard title="Trazabilidad" value="1" status="ok" subtitle="Lote(s) con evidencia" />
          </div>

          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
            <div className="font-semibold">Acciones</div>
            <div className="mt-3 flex gap-2">
              <Link className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" to="/it/asset-ledger">
                Ver Asset Ledger
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
