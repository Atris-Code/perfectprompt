import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Topbar } from "@/components/organisms/Topbar";
import { Sidebar } from "@/components/organisms/Sidebar";
import { api } from "@/lib/api/apiClient";
import { Badge } from "@/components/atoms/Badge";
import { useAuth } from "@/lib/auth/auth";
import { mapGateError } from "@/lib/api/errorMap";

export default function AnalyticsPage() {
  const { id = "024" } = useParams();
  const { auth } = useAuth();
  const token = auth?.token ?? "";

  const [results, setResults] = useState<any[]>([]);
  const [err, setErr] = useState<string | null>(null);

  async function refresh() {
    if (!token) return;
    setResults(await api.labResults(token, id));
  }

  useEffect(() => { refresh().catch((e:any)=>setErr(e.message)); }, [id, token]);

  async function setQc(lrId: string, qc: "Pending"|"Approved"|"Rejected") {
    setErr(null);
    try {
      const updated = await api.setQc(token, lrId, qc);
      setResults((prev) => prev.map((x) => (x.id === updated.id ? updated : x)));
    } catch (e:any) {
      setErr(e.message ?? "Error");
    }
  }

  async function upload(type: string) {
    setErr(null);
    try {
      const fileName = window.prompt(`Nombre del archivo (${type})`, `${type.toLowerCase()}_run${id}.dat`);
      if (!fileName) return;
      const created = await api.uploadLab(token, id, { type, fileUrl: `/evidence/${fileName}` });
      setResults((prev) => [created, ...prev]);
    } catch (e:any) {
      setErr(e.message ?? "Error");
    }
  }

  const pending = results.filter(r => r.qcStatus === "Pending").length;
  const approved = results.filter(r => r.qcStatus === "Approved").length;

  const gate = err ? mapGateError({ message: err }) : null;

  return (
    <div className="min-h-screen flex">
      <Sidebar runId={id} />
      <div className="flex-1">
        <Topbar title={`OT — Analítica & QC (RUN-${id})`} right={
          <div className="flex items-center gap-2">
            <Badge variant={pending ? "warn" : "ok"}>Pending: {pending}</Badge>
            <Badge variant="ok">Approved: {approved}</Badge>
          </div>
        } />
        <div className="p-6 space-y-4">
          {(err || gate) && (
            <div className="rounded-[12px] bg-crit/10 border border-crit/30 p-4">
              <div className="font-semibold">{gate?.title ?? "Error"}</div>
              <div className="text-sm mt-1">{gate?.detail ?? err}</div>
            </div>
          )}

          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
            <div className="font-semibold">Subida de evidencia</div>
            <div className="text-sm text-muted mt-1">Cada upload queda como evidencia con estado QC Pending.</div>
            <div className="mt-3 flex flex-wrap gap-2">
              <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={() => upload("GCMS")}>Upload GC-MS</button>
              <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={() => upload("MICRO_GC")}>Upload Micro-GC</button>
              <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={() => upload("TGA")}>Upload TGA</button>
              <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={refresh}>Refresh</button>
            </div>
          </div>

          {results.map((r) => (
            <div key={r.id} className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
              <div className="flex items-center justify-between">
                <div className="font-semibold">{r.type} <span className="text-xs text-muted font-mono">({r.id})</span></div>
                <Badge variant={r.qcStatus === "Approved" ? "ok" : r.qcStatus === "Rejected" ? "crit" : "warn"}>
                  QC: {r.qcStatus}
                </Badge>
              </div>
              <div className="text-sm text-muted mt-2">Archivo: {r.fileUrl}</div>

              <div className="mt-3 flex gap-2">
                <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={() => setQc(r.id, "Approved")}>Aprobar</button>
                <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={() => setQc(r.id, "Rejected")}>Rechazar</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
