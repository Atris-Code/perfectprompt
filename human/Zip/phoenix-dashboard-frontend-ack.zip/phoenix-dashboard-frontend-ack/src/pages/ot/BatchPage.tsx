import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Topbar } from "@/components/organisms/Topbar";
import { Sidebar } from "@/components/organisms/Sidebar";
import { api } from "@/lib/api/apiClient";
import { Badge } from "@/components/atoms/Badge";
import { useAuth } from "@/lib/auth/auth";
import { mapGateError } from "@/lib/api/errorMap";

export default function BatchPage() {
  const { id = "B-011" } = useParams();
  const { auth } = useAuth();
  const token = auth?.token ?? "";

  const [batch, setBatch] = useState<any>(null);
  const [events, setEvents] = useState<any[]>([]);
  const [err, setErr] = useState<string | null>(null);

  async function refresh() {
    if (!token) return;
    const b = await api.getBatch(token, id);
    setBatch(b);
    setEvents((b?.oracleEvents ?? []) as any[]);
  }

  useEffect(() => { refresh().catch((e:any)=>setErr(e.message)); }, [id, token]);

  async function sign(role: "QA"|"Engineer") {
    setErr(null);
    try {
      await api.approveBatch(token, id, role);
      await refresh();
    } catch (e:any) {
      setErr(e.message ?? "Error");
    }
  }

  async function emit() {
    setErr(null);
    try {
      const ev = await api.emitOracle(token, id);
      setEvents((prev) => [ev, ...prev]);
    } catch (e:any) {
      setErr(e.message ?? "Error");
    }
  }

  const gate = err ? mapGateError({ message: err }) : null;

  return (
    <div className="min-h-screen flex">
      <Sidebar runId="024" />
      <div className="flex-1">
        <Topbar title={`OT — Batch (${id})`} right={
          <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={refresh}>
            Refresh
          </button>
        } />
        <div className="p-6 space-y-4">
          {(err || gate) && (
            <div className="rounded-[12px] bg-crit/10 border border-crit/30 p-4">
              <div className="font-semibold">{gate?.title ?? "Error"}</div>
              <div className="text-sm mt-1">{gate?.detail ?? err}</div>
            </div>
          )}

          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
            {!batch ? (
              <div className="text-sm text-muted">
                No existe aún. Crea el Batch desde Mirror-Check (requiere PASS + firmas QA/ENG + QC Approved + cierre masa ≥95%).
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div className="font-semibold">{batch.id}</div>
                  <Badge variant="ok">{batch.status}</Badge>
                </div>
                <div className="mt-3 text-sm text-muted">Run: {batch.runId}</div>
                <div className="mt-2 text-sm">Aceite validado: <b>{Number(batch.validatedOil_g).toFixed(2)} g</b></div>
                <div className="mt-2 text-sm">Evidence hash: <span className="font-mono">{batch.evidenceHash}</span></div>

                <div className="mt-4 flex flex-wrap gap-2">
                  <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={() => sign("QA")}>
                    Firmar QA
                  </button>
                  <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={() => sign("Engineer")}>
                    Firmar Engineer
                  </button>
                  <button className="px-3 py-2 rounded-xl bg-primary/90 hover:bg-primary font-semibold disabled:opacity-50"
                    onClick={emit}
                    disabled={!batch.approvedByQA || !batch.approvedByEngineer}
                  >
                    Emitir Oráculo
                  </button>
                </div>
              </>
            )}
          </div>

          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
            <div className="font-semibold">Eventos del Oráculo</div>
            {events.length === 0 ? (
              <div className="text-sm text-muted mt-2">Sin eventos aún.</div>
            ) : (
              <div className="mt-3 space-y-2">
                {events.map((e:any) => (
                  <div key={e.id} className="p-3 rounded-xl bg-surface2 border border-borderc">
                    <div className="flex items-center justify-between">
                      <div className="font-semibold text-sm">{e.type}</div>
                      <div className="text-xs text-muted">{new Date(e.ts).toLocaleString()}</div>
                    </div>
                    <div className="text-sm mt-1">Cantidad: <b>{Number(e.quantityKg ?? 0).toFixed(4)} kg</b></div>
                    <div className="text-xs text-muted mt-1 font-mono">evidence: {e.evidenceHash}</div>
                    <div className="text-xs text-muted mt-1 font-mono">sig: {e.oracleSignature}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
