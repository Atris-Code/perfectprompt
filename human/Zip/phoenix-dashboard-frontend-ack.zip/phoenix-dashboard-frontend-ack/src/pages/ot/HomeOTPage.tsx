import { Link } from "react-router-dom";
import { Topbar } from "@/components/organisms/Topbar";
import { Sidebar } from "@/components/organisms/Sidebar";
import { KpiCard } from "@/components/molecules/KpiCard";
import { useAuth } from "@/lib/auth/auth";

export default function HomeOTPage() {
  const { logout, auth } = useAuth();

  return (
    <div className="min-h-screen flex">
      <Sidebar runId="024" />
      <div className="flex-1">
        <Topbar
          title="OT — Home"
          right={
            <div className="flex items-center gap-3">
              <div className="text-sm text-muted">{auth?.user.role}</div>
              <button className="text-sm px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={logout}>
                Salir
              </button>
            </div>
          }
        />
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <KpiCard title="Flujo recomendado" value="HSE → QC → Mirror → Batch → Oráculo" status="info"
              subtitle="Mirror-Check exige Checklist completado y QC aprobado (demo gating)." />
            <KpiCard title="Alarmas" value="Auto" status="ok" subtitle="Se generan si T sale de 598–602°C" />
            <KpiCard title="Cierre de masa requerido" value="≥95" unit="%" status="ok" subtitle="Bloquea creación de Batch si no cumple" />
          </div>

          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
            <div className="font-semibold">Accesos rápidos (RUN-024)</div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" to="/ot/runs/024/live">Live Run</Link>
              <Link className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" to="/ot/runs/024/hse">Checklist HSE</Link>
              <Link className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" to="/ot/runs/024/analytics">Analítica (QC)</Link>
              <Link className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" to="/ot/runs/024/mirror-check">Mirror-Check</Link>
              <Link className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" to="/ot/batches/B-011">Batch</Link>
              <Link className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" to="/it/asset-ledger">Asset Ledger</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
