import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Topbar } from "@/components/organisms/Topbar";
import { Sidebar } from "@/components/organisms/Sidebar";
import { Badge } from "@/components/atoms/Badge";
import { useAuth } from "@/lib/auth/auth";
import { api } from "@/lib/api/apiClient";
import { mapGateError } from "@/lib/api/errorMap";

type ItemKey = "LEAK_CHECK" | "INERTIZATION" | "LINES_HEATED" | "PPE";

const labels: Record<ItemKey, string> = {
  LEAK_CHECK: "Leak check N₂ (2 bar / <0.1 bar en 10 min)",
  INERTIZATION: "Inertización completada (O₂ < 1% o purga equivalente)",
  LINES_HEATED: "Líneas >200°C verificadas (prevención de taponamiento por ceras)",
  PPE: "EPP completo (respiratoria, térmicos/criogénicos, pantalla facial)",
};

export default function HseChecklistPage() {
  const { id = "024" } = useParams();
  const { auth } = useAuth();
  const token = auth?.token ?? "";

  const [state, setState] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  async function refresh() {
    if (!token) return;
    const s = await api.getHse(token, id);
    setState(s);
  }

  useEffect(() => {
    refresh().catch((e:any)=>setErr(e.message));
  }, [id, token]);

  async function toggle(key: ItemKey, checked: boolean) {
    setErr(null);
    try {
      await api.setHseItem(token, id, key, checked);
      await refresh();
    } catch (e:any) {
      setErr(e.message ?? "Error");
    }
  }

  async function uploadEvidence(key: ItemKey) {
    const name = window.prompt("Nombre de archivo (mock URL) p.ej. leakcheck_photo.png");
    if (!name) return;
    try {
      await api.addHseEvidence(token, id, key, { name, url: `/evidence/${name}` });
      await refresh();
    } catch (e:any) {
      setErr(e.message ?? "Error");
    }
  }

  async function sign(role: "Operator" | "HSE") {
    setErr(null);
    try {
      await api.signHse(token, id, role);
      await refresh();
    } catch (e:any) {
      setErr(e.message ?? "Error");
    }
  }

  async function complete() {
    setErr(null);
    try {
      await api.completeHse(token, id);
      await refresh();
    } catch (e:any) {
      setErr(e.message ?? "Error");
    }
  }

  const items = state?.items ?? [];
  const signatures = state?.signatures ?? [];
  const completed = !!state?.completed;

  const allChecked = items.length > 0 && items.every((i:any) => i.checked);
  const signedOp = signatures.some((s:any) => s.role === "Operator");
  const signedHse = signatures.some((s:any) => s.role === "HSE");

  const gate = err ? mapGateError({ message: err }) : null;

  return (
    <div className="min-h-screen flex">
      <Sidebar runId={id} />
      <div className="flex-1">
        <Topbar
          title={`OT — Checklist HSE (RUN-${id})`}
          right={completed ? <Badge variant="ok">COMPLETADO</Badge> : <Badge variant="warn">PENDIENTE</Badge>}
        />
        <div className="p-6 space-y-4">
          {(err || gate) && (
            <div className="rounded-[12px] bg-crit/10 border border-crit/30 p-4">
              <div className="font-semibold">{gate?.title ?? "Error"}</div>
              <div className="text-sm mt-1">{gate?.detail ?? err}</div>
            </div>
          )}

          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft space-y-4">
            <div>
              <div className="font-semibold">Checklist HSE (bloqueante)</div>
              <div className="text-sm text-muted mt-1">Debe completarse para habilitar Mirror-Check.</div>
            </div>

            <div className="space-y-3">
              {(Object.keys(labels) as ItemKey[]).map((k) => {
                const item = items.find((x:any) => x.key === k);
                const evidence = (item?.evidence ?? []) as any[];
                return (
                  <div key={k} className="rounded-xl bg-surface2 border border-borderc p-3 flex items-start justify-between gap-3">
                    <label className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={!!item?.checked}
                        onChange={(e) => toggle(k, e.target.checked)}
                        className="mt-1"
                        disabled={completed}
                      />
                      <div>
                        <div className="text-sm">{labels[k]}</div>
                        <div className="text-xs text-muted mt-1">
                          Evidencia: {evidence.length ? evidence.map(e => e.name).join(", ") : "—"}
                        </div>
                      </div>
                    </label>

                    <button
                      className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface"
                      onClick={() => uploadEvidence(k)}
                      disabled={completed}
                    >
                      Subir evidencia
                    </button>
                  </div>
                );
              })}
            </div>

            <div className="pt-3 border-t border-borderc grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="rounded-xl bg-surface2 border border-borderc p-3">
                <div className="text-xs text-muted">Firma Operador</div>
                <div className="text-sm mt-1">{signedOp ? "OK" : "Pendiente"}</div>
                <button
                  className="mt-2 px-3 py-2 rounded-xl border border-borderc hover:bg-surface disabled:opacity-50"
                  onClick={() => sign("Operator")}
                  disabled={completed || !(auth?.user.role === "Operator" || auth?.user.role === "Admin")}
                >
                  Firmar (Operator)
                </button>
              </div>

              <div className="rounded-xl bg-surface2 border border-borderc p-3">
                <div className="text-xs text-muted">Firma HSE</div>
                <div className="text-sm mt-1">{signedHse ? "OK" : "Pendiente"}</div>
                <button
                  className="mt-2 px-3 py-2 rounded-xl border border-borderc hover:bg-surface disabled:opacity-50"
                  onClick={() => sign("HSE")}
                  disabled={completed || !(auth?.user.role === "HSE" || auth?.user.role === "Admin")}
                >
                  Firmar (HSE)
                </button>
              </div>

              <div className="rounded-xl bg-surface2 border border-borderc p-3">
                <div className="text-xs text-muted">Estado</div>
                <div className="text-sm mt-1">
                  Ítems: {allChecked ? "OK" : "Pendiente"} · Firmas: {(signedOp && signedHse) ? "OK" : "Pendiente"}
                </div>
                <button
                  className="mt-2 w-full px-3 py-2 rounded-xl bg-primary/90 hover:bg-primary font-semibold disabled:opacity-50"
                  onClick={complete}
                  disabled={!allChecked || !signedOp || !signedHse || completed || !(auth?.user.role === "HSE" || auth?.user.role === "Admin")}
                >
                  Completar checklist
                </button>
              </div>
            </div>
          </div>

          <div className="text-xs text-muted">
            Nota: el gating real vive en el backend; la UI solo refleja errores (409).
          </div>
        </div>
      </div>
    </div>
  );
}
