import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Topbar } from "@/components/organisms/Topbar";
import { Sidebar } from "@/components/organisms/Sidebar";
import { GaugeCard } from "@/components/molecules/GaugeCard";
import { AlarmPanel } from "@/components/organisms/AlarmPanel";
import { RunTimeline } from "@/components/organisms/RunTimeline";
import { useWsTelemetry } from "@/lib/telemetry/wsTelemetry";
import { api } from "@/lib/api/apiClient";
import { useAuth } from "@/lib/auth/auth";

export default function LiveRunPage() {
  const { id = "024" } = useParams();
  const { auth } = useAuth();
  const token = auth?.token ?? "";

  const { samples, alarms, setAlarms } = useWsTelemetry(id);
  const [events, setEvents] = useState<any[]>([]);

  useEffect(() => {
    if (!token) return;
    api.listEvents(token, id).then(setEvents).catch(() => setEvents([]));
  }, [id, token]);

  useEffect(() => {
    if (!token) return;
    // preload persisted alarms (so no se pierden si recargas)
    api.alarms(token, id).then((rows) => {
      setAlarms((prev: any[]) => {
        const merged = [...rows, ...prev].reduce((acc: any[], a: any) => {
          if (!acc.some(x => x.id === a.id)) acc.push(a);
          return acc;
        }, []);
        return merged.sort((a,b) => new Date(b.ts).getTime() - new Date(a.ts).getTime()).slice(0, 100);
      });
    }).catch(() => void 0);
  }, [id, token, setAlarms]);

  const T = samples.T_REACTOR?.value ?? 0;
  const P = samples.P_REACTOR?.value ?? 0;
  const N2 = samples.N2_FLOW?.value ?? 0;

  async function addEvent() {
    const desc = window.prompt("Describe el evento (p.ej., 'Cambio trampa condensador')");
    if (!desc || !token) return;
    const created = await api.addEvent(token, id, desc);
    setEvents((prev) => [created, ...prev]);
  }

  async function acknowledgeAlarm(alarmId: string) {
    if (!token) return;
    const updated = await api.ackAlarm(token, alarmId);
    // update local state immediately
    setAlarms((prev: any[]) => prev.map(a => a.id === updated.id ? { ...a, ...updated } : a));
  }

  return (
    <div className="min-h-screen flex">
      <Sidebar runId={id} />
      <div className="flex-1">
        <Topbar
          title={`OT — Live Run (RUN-${id})`}
          right={
            <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2 text-sm" onClick={addEvent}>
              Registrar evento
            </button>
          }
        />
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <GaugeCard title="Temperatura Reactor" value={T} unit="°C" min={0} max={800} greenRange={[598, 602]} />
            <GaugeCard title="Presión Reactor" value={P} unit="bar" min={0} max={5} />
            <GaugeCard title="Flujo N₂" value={N2} unit="mL/min" min={0} max={200} />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <AlarmPanel alarms={alarms} onAcknowledge={acknowledgeAlarm} />
            <RunTimeline events={events.map((e:any)=>({ id: e.id, runId: e.runId, description: e.message, ts: e.ts, by: e.by }))} />
          </div>
        </div>
      </div>
    </div>
  );
}
