import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { Topbar } from "@/components/organisms/Topbar";
import { Sidebar } from "@/components/organisms/Sidebar";
import { api } from "@/lib/api/apiClient";
import { Badge } from "@/components/atoms/Badge";
import { useAuth } from "@/lib/auth/auth";
import { mapGateError } from "@/lib/api/errorMap";

export default function MassBalancePage() {
  const { id = "024" } = useParams();
  const { auth } = useAuth();
  const token = auth?.token ?? "";

  const [records, setRecords] = useState<any[]>([]);
  const [mb, setMb] = useState<{ feed: number; liq: number; gas: number; sol: number; closure: number } | null>(null);
  const [err, setErr] = useState<string | null>(null);

  async function refresh() {
    if (!token) return;
    const [recs, bal] = await Promise.all([api.massRecords(token, id), api.massBalance(token, id)]);
    setRecords(recs);
    setMb(bal);
  }

  useEffect(() => { refresh().catch((e:any)=>setErr(e.message)); }, [id, token]);

  const ok = (mb?.closure ?? 0) >= 95;
  const statusBadge = ok ? <Badge variant="ok">≥95% OK</Badge> : <Badge variant="crit">&lt;95% BLOQUEO</Badge>;

  const totals = useMemo(() => {
    const sum = (t: string) => records.filter(r => r.type === t).reduce((s:number,r:any)=>s+r.mass_g,0);
    return { FEED: sum("FEED"), LIQUID: sum("LIQUID"), GAS: sum("GAS"), SOLID: sum("SOLID") };
  }, [records]);

  async function addRecord() {
    setErr(null);
    try {
      const type = (window.prompt("Tipo (FEED | LIQUID | GAS | SOLID)", "LIQUID") ?? "").toUpperCase();
      if (!["FEED","LIQUID","GAS","SOLID"].includes(type)) throw new Error("Tipo inválido.");
      const massStr = window.prompt("Masa (g)", "0");
      if (!massStr) return;
      const mass_g = Number(massStr);
      if (!Number.isFinite(mass_g) || mass_g < 0) throw new Error("Masa inválida.");
      const scaleId = (window.prompt("Scale ID (opcional)", "scale-1") ?? "").trim() || undefined;
      const method = (window.prompt("Método (opcional)", type === "GAS" ? "wet-gas-meter" : "weighing") ?? "").trim() || undefined;

      await api.addMassRecord(token, id, { type, mass_g, scaleId, method, uncertainty_g: 0.01 });
      await refresh();
    } catch (e:any) {
      setErr(e.message ?? "Error");
    }
  }

  const gate = err ? mapGateError({ message: err }) : null;

  return (
    <div className="min-h-screen flex">
      <Sidebar runId={id} />
      <div className="flex-1">
        <Topbar title={`OT — Balance de Masa (RUN-${id})`} right={
          <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={addRecord}>
            Registrar pesada
          </button>
        } />
        <div className="p-6 space-y-4">
          {(err || gate) && (
            <div className="rounded-[12px] bg-crit/10 border border-crit/30 p-4">
              <div className="font-semibold">{gate?.title ?? "Error"}</div>
              <div className="text-sm mt-1">{gate?.detail ?? err}</div>
            </div>
          )}

          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
            <div className="flex items-center justify-between">
              <div className="font-semibold">Resumen</div>
              {statusBadge}
            </div>
            {!mb ? (
              <div className="text-sm text-muted mt-3">Cargando…</div>
            ) : (
              <div className="mt-4 grid grid-cols-2 md:grid-cols-5 gap-3">
                <div><div className="text-xs text-muted">Feed</div><div className="text-lg font-semibold">{mb.feed.toFixed(2)} g</div></div>
                <div><div className="text-xs text-muted">Líquidos</div><div className="text-lg font-semibold">{mb.liq.toFixed(2)} g</div></div>
                <div><div className="text-xs text-muted">Gas</div><div className="text-lg font-semibold">{mb.gas.toFixed(2)} g</div></div>
                <div><div className="text-xs text-muted">Sólidos</div><div className="text-lg font-semibold">{mb.sol.toFixed(2)} g</div></div>
                <div><div className="text-xs text-muted">Cierre</div><div className="text-lg font-semibold">{mb.closure.toFixed(1)} %</div></div>
              </div>
            )}
          </div>

          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
            <div className="flex items-center justify-between">
              <div className="font-semibold">Registros</div>
              <div className="text-xs text-muted">
                Totales (g): FEED {totals.FEED.toFixed(2)} · LIQ {totals.LIQUID.toFixed(2)} · GAS {totals.GAS.toFixed(2)} · SOL {totals.SOLID.toFixed(2)}
              </div>
            </div>

            <table className="w-full mt-4 text-sm">
              <thead className="text-muted">
                <tr className="text-left">
                  <th className="py-2">TS</th>
                  <th>Tipo</th>
                  <th>Masa (g)</th>
                  <th>Scale</th>
                  <th>Método</th>
                </tr>
              </thead>
              <tbody>
                {records.length === 0 ? (
                  <tr><td className="py-3 text-muted" colSpan={5}>Sin registros.</td></tr>
                ) : records.map((r:any) => (
                  <tr key={r.id} className="border-t border-borderc">
                    <td className="py-2 text-xs text-muted">{new Date(r.ts).toLocaleString()}</td>
                    <td className="font-mono">{r.type}</td>
                    <td>{Number(r.mass_g).toFixed(2)}</td>
                    <td className="text-xs text-muted">{r.scaleId ?? "—"}</td>
                    <td className="text-xs text-muted">{r.method ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
