import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Topbar } from "@/components/organisms/Topbar";
import { Sidebar } from "@/components/organisms/Sidebar";
import { api } from "@/lib/api/apiClient";
import { Badge } from "@/components/atoms/Badge";
import { useAuth } from "@/lib/auth/auth";
import { mapGateError } from "@/lib/api/errorMap";

export default function MirrorCheckPage() {
  const { id = "024" } = useParams();
  const { auth } = useAuth();
  const token = auth?.token ?? "";

  const [mc, setMc] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  async function run() {
    setErr(null);
    try {
      const res = await api.runMirror(token, id);
      setMc(res);
    } catch (e: any) {
      setMc(null);
      setErr(e.message ?? "Error");
    }
  }

  async function refresh() {
    setErr(null);
    try {
      const res = await api.getMirror(token, id);
      setMc(res);
    } catch (e:any) {
      // ignore if not run yet
    }
  }

  useEffect(() => { run(); }, [id, token]);

  const badge = mc?.result === "PASS" ? "ok" : "crit";
  const sigs = mc?.signatures ?? [];
  const signedQA = sigs.some((s:any) => s.role === "QA");
  const signedEng = sigs.some((s:any) => s.role === "Engineer");

  const canSignQA = auth?.user.role === "QA" || auth?.user.role === "Admin";
  const canSignEng = auth?.user.role === "Engineer" || auth?.user.role === "Admin";

  async function sign(role: "QA" | "Engineer") {
    setErr(null);
    try {
      await api.signMirror(token, id, role);
      await refresh();
    } catch (e:any) {
      setErr(e.message ?? "Error");
    }
  }

  const gate = err ? mapGateError({ message: err }) : null;

  return (
    <div className="min-h-screen flex">
      <Sidebar runId={id} />
      <div className="flex-1">
        <Topbar title={`OT — Mirror-Check (RUN-${id})`} right={
          <button className="px-3 py-2 rounded-xl border border-borderc hover:bg-surface2" onClick={run}>
            Ejecutar / Recalcular
          </button>
        }/>
        <div className="p-6 space-y-4">
          {(err || gate) && (
            <div className="rounded-[12px] bg-warn/10 border border-warn/30 p-4">
              <div className="font-semibold">{gate?.title ?? "Bloqueo / Error"}</div>
              <div className="text-sm mt-1">{gate?.detail ?? err}</div>
              {gate?.links?.length ? (
                <div className="text-sm mt-2">
                  {gate.links.map(l => (
                    <Link key={l.to} className="underline mr-4" to={l.to}>{l.label}</Link>
                  ))}
                </div>
              ) : (
                <div className="text-sm mt-2">
                  Pre-condiciones típicas: <Link className="underline" to={`/ot/runs/${id}/hse`}>Checklist HSE</Link> + QC Approved en <Link className="underline" to={`/ot/runs/${id}/analytics`}>Analítica</Link>.
                </div>
              )}
            </div>
          )}

          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
            <div className="flex items-center justify-between">
              <div className="font-semibold">Resultado</div>
              {mc && <Badge variant={badge as any}>{mc.result}</Badge>}
            </div>

            {mc && (
              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted">Targets</div>
                  <div className="mt-2">Líquidos: {mc.targets.liquids.toFixed(2)}%</div>
                  <div>Gas: {mc.targets.gas.toFixed(2)}%</div>
                  <div>Coque: {mc.targets.coke.toFixed(2)}%</div>
                </div>
                <div>
                  <div className="text-muted">Actual</div>
                  <div className="mt-2">Líquidos: {mc.actuals.liquids.toFixed(2)}%</div>
                  <div>Gas: {mc.actuals.gas.toFixed(2)}%</div>
                  <div>Coque: {mc.actuals.coke.toFixed(2)}%</div>
                  <div>Cierre masa: {mc.actuals.massClosure.toFixed(1)}%</div>
                </div>
              </div>
            )}
          </div>

          <div className="rounded-[12px] bg-surface border border-borderc p-4 shadow-soft">
            <div className="flex items-center justify-between">
              <div className="font-semibold">Firmas Mirror-Check (bloqueantes para Batch)</div>
              <div className="flex gap-2">
                <Badge variant={signedQA ? "ok" : "warn"}>QA: {signedQA ? "OK" : "Pendiente"}</Badge>
                <Badge variant={signedEng ? "ok" : "warn"}>ENG: {signedEng ? "OK" : "Pendiente"}</Badge>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="rounded-xl bg-surface2 border border-borderc p-3">
                <div className="text-xs text-muted">Firma QA</div>
                <button className="mt-2 px-3 py-2 rounded-xl border border-borderc hover:bg-surface2 disabled:opacity-50"
                  onClick={() => sign("QA")} disabled={!mc || mc.result !== "PASS" || signedQA || !canSignQA}>
                  Firmar QA
                </button>
              </div>

              <div className="rounded-xl bg-surface2 border border-borderc p-3">
                <div className="text-xs text-muted">Firma Engineer</div>
                <button className="mt-2 px-3 py-2 rounded-xl border border-borderc hover:bg-surface2 disabled:opacity-50"
                  onClick={() => sign("Engineer")} disabled={!mc || mc.result !== "PASS" || signedEng || !canSignEng}>
                  Firmar Engineer
                </button>
              </div>
            </div>

            <div className="mt-4">
              <button
                className="px-3 py-2 rounded-xl bg-primary/90 hover:bg-primary font-semibold disabled:opacity-50"
                onClick={async () => {
                  setErr(null);
                  try {
                    const b = await api.createBatch(token, id);
                    alert(`Batch creado: ${b.id}`);
                  } catch (e:any) {
                    setErr(e.message ?? "Error");
                  }
                }}
                disabled={!mc || mc.result !== "PASS" || !signedQA || !signedEng}
              >
                Crear Batch (PASS + firmas)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
