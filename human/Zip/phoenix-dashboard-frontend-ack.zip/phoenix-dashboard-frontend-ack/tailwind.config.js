/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "hsl(var(--bg))",
        surface: "hsl(var(--surface))",
        surface2: "hsl(var(--surface-2))",
        text: "hsl(var(--text))",
        muted: "hsl(var(--text-muted))",
        borderc: "hsl(var(--border))",
        ok: "hsl(var(--ok))",
        warn: "hsl(var(--warn))",
        crit: "hsl(var(--crit))",
        info: "hsl(var(--info))",
        primary: "hsl(var(--primary))",
        hse: "hsl(var(--hse))",
        stop: "hsl(var(--stop))",
      },
      borderRadius: { card: "12px" },
      boxShadow: {
        soft: "0 10px 30px rgba(0,0,0,0.25)",
      },
    },
  },
  plugins: [],
};
